# Change Log

## [2.1.1 - 2019-12-14]

### Fixed

- Add Docs to .npmignore

## [2.1.0 - 2019-12-14]

### Added

- Update node-rpio from 1.0.13 to 1.3.0
- Extended Information about card register
- Example how to change authentication key for card register (test\writeAuthenticationKey.js)
- Extended Readme & Documentation
- Buzzer Notifications (optional)
- Circuit Diagram