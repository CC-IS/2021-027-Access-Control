# Demonstration

Those are some images related to a real module build with `mfrc522-rpi` library.

![pic_1](demonstration/1.jpg)
![pic_2](demonstration/2.jpg)
![pic_3](demonstration/3.jpg)
![pic_4](demonstration/4.jpg)
![pic_5](demonstration/5.jpg)
![pic_6](demonstration/6.jpg)
![pic_7](demonstration/7.jpg)
![pic_9](demonstration/9.jpg)

**Video demo**

![Example](https://github.com/firsttris/mfrc522-rpi/raw/master/docs/demonstration/demo.gif)

[Watch on Youtube (with sound)](https://youtu.be/e5D_fy8IIjY)
